
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'groupcounseling',
  applicationName: 'groupcounseling-app',
  appUid: 'tS1kcqz63PhQnMdvVn',
  orgUid: '844d5c57-dee4-42b2-b2ce-312bc766d0c2',
  deploymentUid: 'c7b5fe7b-4953-41f8-94f9-0c766507ef51',
  serviceName: 'GroupCounseling-app',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.5.1',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'GroupCounseling-app-dev-register', timeout: 6 };

try {
  const userHandler = require('./apis/user/handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.register, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}